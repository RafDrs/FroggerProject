def organiser():    
    right_car=RightCar(607,605,2,-10)#1h seira
    right_car2=RightCar(907,605,2,-10)#1h seira
    right_car3=RightCar(600,491,2,-10)#3h seira
    right_car4=RightCar(900,491,2,-10)#3h seira
    left_car=LeftCar(-120,548,2,10)#2h seira
    left_car2=LeftCar(-600,548,2,10)#2h seira
    left_car3=LeftCar(-120,434,2,10)#4h seira
    left_car4=LeftCar(-300,434,2,10)#4h seira
    left_car5=LeftCar(-650,434,3,10)# 4h seira
    right_f1=RightF1(-900,381,2,-13)
    player = Frog(280,675)#spawn point vatraxou
    pl_rect=player.rect
    left_car_rect=left_car.car_rect
    left_car2_rect=left_car2.car_rect
    right_car_rect=right_car.car_rect
    right_car2_rect=right_car2.car_rect



    log_1=Log(607,377-57-57,2,7)#1h seira
    log_2=Log(950,377-57-57,2,7)#1h seira
    log_3=Log(950,320-57-57,2,-7)#2h seira
    log_4=Log(600,320-57-57,2,-7)#2h seira
    log_5=Log(700,320-57-57-57,2,9)#3h
    log_6=Log(100,320-57-57-57,2,9)#3h
    log_7=Log(350,320-4*57,2,10)#4h
    log_8=Log(550,320-4*57,2,10)#4h
    log_9=Log(450,330-5*57-10,2,-9)#5h
    log_10=Log(950,330-5*57-10,2,-9)#5h

    l=[right_f1,left_car,left_car2,right_car,right_car2,right_car3,right_car4,left_car4,left_car3,left_car5,log_1,log_2,log_3,log_4,log_5,log_6,log_7,log_8,log_9,log_10]

    return l, player