import pygame

pygame.init()
black = (0, 0, 0)
WIDTH, HEIGHT = 607, 720
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("The Frogger")
pygame.display.set_icon(pygame.image.load("frog_up.png"))
bg = pygame.image.load("bg.png")


class Frog:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.image = pygame.image.load("frog_up.png").convert_alpha()
        self.image_up = pygame.image.load("frog_up.png").convert_alpha()
        self.image_right = pygame.image.load("frog_right.png").convert_alpha()
        self.image_down = pygame.image.load("frog_down.png").convert_alpha()
        self.image_left = pygame.image.load("frog_left.png").convert_alpha()
        self.rect = self.image.get_rect(midbottom=(self.x, self.y))

    def draw(self, surface):
        surface.blit(self.image, (self.x, self.y))


class MovingObject:
    def __init__(self, x, y, image_path, speed):
        self.x = x
        self.y = y
        self.image = pygame.image.load(image_path).convert_alpha()
        self.speed = speed
        self.rect = self.image.get_rect(midbottom=(self.x, self.y))

    def draw(self, surface):
        surface.blit(self.image, (self.x, self.y))

    def drive(self):
        self.x += self.speed
        if self.speed > 0 and self.x > WIDTH:
            self.x = -self.rect.width
        elif self.speed < 0 and self.x < -self.rect.width:
            self.x = WIDTH


def collision(player):
    player_rect=player.image.get_rect(midbottom=(player.x,player.y))
    logs,cars=rect_create()
    for i in cars:
            if i.colliderect(player_rect):
                print("game over")
                game_over_image=pygame.image.load("game_over_fs.png").convert_alpha()
                SCREEN.blit(game_over_image,(WIDTH,HEIGHT))
              
                
    for i in logs:
            pass
 
    
    


def handle_events(player):
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            return False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                player.x += 56
                player.image = player.image_right
            elif event.key == pygame.K_LEFT:
                player.x -= 56
                player.image = player.image_left
            elif event.key == pygame.K_DOWN:
                player.y += 56
                player.image = player.image_down
            elif event.key == pygame.K_UP:
                player.y -= 56
                player.image = player.image_up
    return True
def rect_create():  #dhmhourgei rects gia na ginei to collision
    cars=[]
    logs=[]
    for i in moving_objects:
        if i.image !="log.png":
            cars.append(i.image.get_rect(midbottom=(i.x,i.y)))
        else:
            logs.append(i.image_path.get_rect(midbottom=(i.x,i.y)))
    return logs,cars


def main():
    clock = pygame.time.Clock()
    run = True
    player = Frog(280, 675)
    global moving_objects
    moving_objects = [
        MovingObject(607, 605+10, "carnew.png", -5),
        MovingObject(907, 605+10, "carnew.png", -5),
        MovingObject(600, 491+10, "carnew.png", -5),
        MovingObject(900, 491+10, "carnew.png", -5),
        MovingObject(-120, 548+10, "car2new.png", 5),
        MovingObject(-600, 548+10, "car2new.png", 5),
        MovingObject(-120, 445, "car2new.png", 5),
        MovingObject(-300, 445, "car2new.png", 5),
        MovingObject(-650, 445, "car2new.png", 5),
        MovingObject(-900, 381+10, "f1.png", -6),
        MovingObject(607, 377 - 57 - 57+10, "log.png", 3),
        MovingObject(950, 377 - 57 - 57+10, "log.png", 3),
        MovingObject(950, 320 - 57 - 57+10, "log.png", -3),
        MovingObject(600, 320 - 57 - 57+10, "log.png", -3),
        MovingObject(700, 320 - 57 - 57 - 57+10, "log.png", 4),
        MovingObject(100, 320 - 57 - 57 - 57+10, "log.png", 4),
        MovingObject(350, 320 - 4 * 57+10, "log.png", -5),
        MovingObject(550, 320 - 4 * 57+10, "log.png", -5),
        MovingObject(450, 330 - 5 * 57 , "log.png", 4),
        MovingObject(950, 330 - 5 * 57 , "log.png", 4),
    ]

    while run==True:
        run = handle_events(player)

        for obj in moving_objects:
            obj.drive()

        if player.x <= 0 or player.y <= 0 or player.x >= WIDTH - 45 or player.y >= HEIGHT - 45:
            player.x = max(0, min(player.x, WIDTH - 45))
            player.y = max(0, min(player.y, HEIGHT - 45))
        

        collision(player)
            

        SCREEN.blit(bg, (0, 0))
        player.draw(SCREEN)

        for obj in moving_objects:
            obj.draw(SCREEN)

        pygame.display.update()
        clock.tick(60)
    else:
        pygame.quit()


if __name__ == "__main__":
    main()
