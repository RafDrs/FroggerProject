import pygame
import time
import sys



# Initialize Pygame
pygame.init()

# Constants

FPS = 60
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
FONT_SIZE = 36
WIDTH, HEIGHT = 607, 720
GAME_OVER_MESSAGE_WIDTH, GAME_OVER_MESSAGE_HEIGHT = 148, 29
PRESS_ANY_TO_CONTINUE_WIDTH,PRESS_ANY_TO_CONTINUE_HEIGHT=460,145
MENU_WIDTH,MENU_HEIGHT=607,720

# Set up the screen
menu_screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Frogger Menu")
clock = pygame.time.Clock()
game_over = False
black = (0, 0, 0)
SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("The Frogger")
pygame.display.set_icon(pygame.image.load("frog_up.png"))
bg = pygame.image.load("bg.png")


# Fonts
font = pygame.font.Font(None, FONT_SIZE)

# Button class
class Button:
    def __init__(self, text, x, y, width, height, action=None):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.action = action

    def draw(self):
        pygame.draw.rect(menu_screen, WHITE, self.rect)
        draw_text(self.text, font, BLACK, self.rect.x + self.rect.width // 2, self.rect.y + self.rect.height // 2)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if self.action:
                    self.action()

# Function to start the main program
def start_game():
    global run
    run = True  # Reset game state
    main() 

# Function to show credits
def show_credits():
    print("Game Credits")

# Function to quit the game
def quit_game():
    pygame.quit()
    sys.exit()

# Buttons
play_button = Button("Play", WIDTH // 2 - 100, HEIGHT // 2 - 50, 200, 50, action=start_game)
credits_button = Button("Credits", WIDTH // 2 - 100, HEIGHT // 2 + 20, 200, 50, action=show_credits)
quit_button = Button("Quit", WIDTH // 2 - 100, HEIGHT // 2 + 90, 200, 50, action=quit_game)

buttons = [play_button, credits_button, quit_button]

def draw_text(text, font, color, x, y):
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(center=(x, y))
    menu_screen.blit(text_surface, text_rect)

# Menu loop
def menu():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
            for button in buttons:
                button.handle_event(event)

        menu_screen.fill(BLACK)

        draw_text("Frogger Menu", font, WHITE, WIDTH // 2, HEIGHT // 4)
        menu_bg=pygame.image.load("menu_screen.png")
        menu_screen.blit(menu_bg,(WIDTH / 2 -MENU_WIDTH  / 2, HEIGHT / 2 - MENU_HEIGHT / 2))

        for button in buttons:
            button.draw()

        pygame.display.flip()
        clock.tick(FPS)





class Frog:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.image = pygame.image.load("frog_up.png").convert_alpha()
        self.image_up = pygame.image.load("frog_up.png").convert_alpha()
        self.image_right = pygame.image.load("frog_right.png").convert_alpha()
        self.image_down = pygame.image.load("frog_down.png").convert_alpha()
        self.image_left = pygame.image.load("frog_left.png").convert_alpha()
        self.rect = self.image.get_rect(midbottom=(self.x, self.y))

    def draw(self, surface):
        surface.blit(self.image, (self.x, self.y))


class MovingObject:
    def __init__(self, x, y, image_path, speed):
        self.x = x
        self.y = y
        self.image = pygame.image.load(image_path).convert_alpha()
        self.speed = speed
        self.rect = self.image.get_rect(midbottom=(self.x, self.y))

    def draw(self, surface):
        surface.blit(self.image, (self.x, self.y))

    def drive(self):
        self.x += self.speed
        if self.speed > 0 and self.x > WIDTH:
            self.x = -self.rect.width
        elif self.speed < 0 and self.x < -self.rect.width:
            self.x = WIDTH


def collision(player):
    player_rect = player.image.get_rect(midbottom=(player.x, player.y))
    logs, cars = rect_create()
    global game_over
    for i in cars:
        if i.colliderect(player_rect):
            game_over = True
            print("game over, hit by car")
            game_over_message = pygame.image.load("game_over_message.png")
            press_any_to_continue=pygame.image.load("retry-removebg-preview.png")
            SCREEN.blit(press_any_to_continue,(WIDTH / 2 - PRESS_ANY_TO_CONTINUE_WIDTH / 2, HEIGHT / 2 - PRESS_ANY_TO_CONTINUE_HEIGHT / 2))
            SCREEN.blit(game_over_message, (WIDTH / 2 - GAME_OVER_MESSAGE_WIDTH / 2, HEIGHT / 2 - GAME_OVER_MESSAGE_HEIGHT / 2))
            game_over=True

            pygame.display.update()
            time.sleep(2)
            


def handle_events(player):
    global game_over
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            print("player x ", player.x, "  y ", player.y)
            if event.key == pygame.K_RIGHT:
                player.x += 56
                player.image = player.image_right
            elif event.key == pygame.K_LEFT:
                player.x -= 56
                player.image = player.image_left
            elif event.key == pygame.K_DOWN:
                player.y += 56
                player.image = player.image_down
            elif event.key == pygame.K_UP:
                player.y -= 56
                player.image = player.image_up
            elif event.key==pygame.K_ESCAPE:
                menu()



            if game_over:
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key!=pygame.K_ESCAPE:
                            player.x = 280
                            player.y = 675
                        else:
                            menu()
            
    return True


def rect_create():
    cars = []
    logs = []
    for i in moving_objects:
        cars.append(i.image.get_rect(midbottom=(i.x, i.y)))
    for i in moving_objects2:
        logs.append(i.image.get_rect(midbottom=(i.x, i.y)))
    return logs, cars


def main():
    global game_over
    clock = pygame.time.Clock()
    run = True
    player = Frog(280, 675)
    isStandingOnALog = False
    global moving_objects
    global moving_objects2
    moving_objects = [
        MovingObject(607, 605 + 10, "carnew.png", -5),
        MovingObject(907, 605 + 10, "carnew.png", -5),
        MovingObject(600, 491 + 10, "carnew.png", -5),
        MovingObject(900, 491 + 10, "carnew.png", -5),
        MovingObject(-120, 548 + 10, "car2new.png", 5),
        MovingObject(-600, 548 + 10, "car2new.png", 5),
        MovingObject(-120, 445, "car2new.png", 5),
        MovingObject(-650, 445, "car2new.png", 5),
        MovingObject(-900, 381 + 10, "f1.png", -6)
    ]
    moving_objects2 = [
        MovingObject(607, 377 - 57 - 57 + 10, "log.png", 2),
        MovingObject(950, 377 - 57 - 57 + 10, "log.png", 2),
        MovingObject(950, 320 - 57 - 57 + 10, "log.png", -2),
        MovingObject(600, 320 - 57 - 57 + 10, "log.png", -2),
        MovingObject(700, 320 - 57 - 57 - 57 + 10, "log.png", 3),
        MovingObject(100, 320 - 57 - 57 - 57 + 10, "log.png", 3),
        MovingObject(350, 320 - 4 * 57 + 10, "log.png", -5),
        MovingObject(550, 320 - 4 * 57 + 10, "log.png", -5),
        MovingObject(450, 330 - 5 * 57, "log.png", 4),
        MovingObject(950, 330 - 5 * 57, "log.png", 4)
    ]

    while run:
        if not game_over:
            handle_events(player)
        else:
            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key!=pygame.K_ESCAPE:
                        player.x = 280
                        player.y = 675
                        game_over=False
                    else:
                        menu()
                    

        pygame.display.update()

        if player.y < HEIGHT / 2 - 45 and player.y > 60 and isStandingOnALog:
            isStandingOnALog = False

        for obj in moving_objects:
            obj.drive()

        for obj in moving_objects2:
            obj.drive()
            if player.y >= obj.y - 30 and player.y <= obj.y + 30 and player.x >= obj.x and player.x <= obj.x + obj.rect.width:
                isStandingOnALog = True
                player.x = obj.x + obj.rect.width / 2

        if player.x <= 0 or player.y <= 0 or player.x >= WIDTH - 45 or player.y >= HEIGHT - 45:
            player.x = max(0, min(player.x, WIDTH - 45))
            player.y = max(0, min(player.y, HEIGHT - 45))

        SCREEN.blit(bg, (0, 0))

        for obj in moving_objects2:
            obj.draw(SCREEN)

        player.draw(SCREEN)

        for obj in moving_objects:
            obj.draw(SCREEN)

        pygame.display.update()

        collision(player)


        if player.y < 5:
            print("You win!")
            you_win_message = pygame.image.load("you_win_message.png")
            press_any_to_continue=pygame.image.load("retry-removebg-preview.png")
            SCREEN.blit(press_any_to_continue,(WIDTH / 2 - PRESS_ANY_TO_CONTINUE_WIDTH / 2, HEIGHT / 2 - PRESS_ANY_TO_CONTINUE_HEIGHT / 2))
            SCREEN.blit(you_win_message, (WIDTH / 2 - GAME_OVER_MESSAGE_WIDTH / 2, HEIGHT / 2 - GAME_OVER_MESSAGE_HEIGHT / 2))
            game_over=True
            pygame.display.update()
            time.sleep(2)

        if player.y < HEIGHT / 2 - 45 and player.y > 60 and not isStandingOnALog:
            print("drowned")
            game_over=True
            if pygame.event.get() == pygame.KEYDOWN :
                if event.key!=pygame.K_ESCAPE:
                    player.x = 280
                    player.y = 675
                else:
                    menu()
               

                run = True

            pygame.display.update()

            game_over_message = pygame.image.load("game_over_message.png")
            SCREEN.blit(game_over_message, (WIDTH / 2 - GAME_OVER_MESSAGE_WIDTH / 2, HEIGHT / 2 - GAME_OVER_MESSAGE_HEIGHT / 2))
            press_any_to_continue=pygame.image.load("retry-removebg-preview.png")
            SCREEN.blit(press_any_to_continue,(WIDTH / 2 - PRESS_ANY_TO_CONTINUE_WIDTH / 2, HEIGHT / 2 - PRESS_ANY_TO_CONTINUE_HEIGHT / 2))
            pygame.display.update()
            time.sleep(2)

        clock.tick(60)

    pygame.quit()


if __name__ == "__main__":
    menu()
