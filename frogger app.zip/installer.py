import PyInstaller as  inst
inst.pyinstaller("starting programm.py")